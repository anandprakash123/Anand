package com.smi.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.smi.model.User;


public class UserDao {
	private Connection con;
	private String query;
	private PreparedStatement pst;
	private ResultSet rs;
	public UserDao(Connection con) {
		this.con = con;
	}
	public User userlogic(String email,String password) {
User user=null;
try {
	query="select * from users where email=? and password=?";
	pst=this.con.prepareStatement(query);
	pst.setString(1, email);
	pst.setString(2, password);
	rs =pst.executeQuery();
	
	if(rs.next()) {
		user= new User();
		user.setId(rs.getInt("id"));
		user.setName(rs.getString(0));
		user.setEmail(rs.getString("email"));
	}
	
	pst.executeQuery();
}catch(Exception e) {
	e.printStackTrace();
	System.out.print(e.getMessage());
}
return user;
}
	public User userlogics(String name,String email,String password,String Age,String Place,String Country,String Phone) {
		User user=null;
		try {
			query="insert into users(name,email,password,Age,Place,Country,Phone) values(?,?,?,?,?,?,?)";
			pst=this.con.prepareStatement(query);
			
			pst.setString(2, name);
			pst.setString(3, email);
			pst.setString(4, password);
			pst.setString(5, Age);
			pst.setString(6, Place);
			pst.setString(7, Country);
			pst.setString(7, Phone);
			
			 int rowsAffected = pst.executeUpdate();
			
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.print(e.getMessage());
		}
		return user;
		}

	/*public boolean register(User u) {
		boolean f = false;

		try  {
			String sql = "insert into users(name,email,password,Age,Place,Country,Phone) values(?,?,?,?,?,?,?) ";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, u.getName());
			ps.setString(2, u.getEmail());
			ps.setString(3, u.getPassword());
            ps.setString(3, u.getAge());
            ps.setString(3, u.getPlace());
            ps.setString(3, u.getCountry());
            ps.setString(3, u.getPhone());
			int i = ps.executeUpdate();

			if (i == 1) {
				f = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return f;
	}*/
}
