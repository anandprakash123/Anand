package com.smi.servlet;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smi.dao.*;
import com.smi.connection.*;
import com.smi.model.*;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		try {
			int id = Integer.parseInt(req.getParameter("id")); 
			String name = req.getParameter("name");
			String email = req.getParameter("email");
			String password = req.getParameter("password");
			String Age = req.getParameter("Age");
			String Place = req.getParameter("Place");
			String Country = req.getParameter("Country");
			String Phone = req.getParameter("Phone");


			User u = new User(1, name, email, password,Age,Place,Country,Phone);

			UserDao dao = new UserDao(DbCon.getConnection());

			HttpSession session = req.getSession();

			boolean f = dao.userlogics(u);  

			if (f) {

				session.setAttribute("sucMsg", "Registered Sucessfully");
				resp.sendRedirect("login.jsp");

			} else {
				session.setAttribute("errorMsg", "Something wrong on server");
				resp.sendRedirect("login.jsp");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

} 