package com.smi.model;

public class User {
	private int id;
	public String getAge() {
		return Age;
	}

	public void setAge(String age) {
		Age = age;
	}

	public String getPlace() {
		return Place;
	}

	public void setPlace(String place) {
		Place = place;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		Country = country;
	}

	public String getPhone() {
		return Phone;
	}

	public void setPhone(String phone) {
		Phone = phone;
	}

	private String name;
	private String email;
	private String password;
	private String Age;
	private String Place;
	private String Country;
	private String Phone;
	
	
	public User() {
		
	}

	public User(int id,String name,String email,String password,String Age,String Place,String Country,String Phone) {
		
		this.id = id;
		this.name = name;
		this.email = email;
		this.password = password;
		this.Age = Age;
		this.Place = Place;
		this.Country = Country;
		this.Phone = Phone;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
